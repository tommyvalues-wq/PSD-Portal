const { load } = require('./db');

function attachUser(req, res, next) {
  const db = load();
  req.user = null;
  if (req.session?.userId) {
    req.user = db.users.find(u => u.id == req.session.userId) || null;
  }
  res.locals.user = req.user;
  res.locals.roles = { owner: 'Owner', pst: 'Professional Standards', member: 'Member' };
  next();
}

function requireLogin(req, res, next) {
  if (!req.user) return res.redirect('/login');
  if (!req.user.is_allowed) return res.redirect('/denied');
  next();
}

function requirePST(req, res, next) {
  if (!req.user) return res.redirect('/login');
  if (!req.user.is_allowed) return res.redirect('/denied');
  if (!['owner', 'pst'].includes(req.user.role)) return res.redirect('/denied');
  next();
}

function requireOwner(req, res, next) {
  if (!req.user) return res.redirect('/login');
  if (!req.user.is_allowed) return res.redirect('/denied');
  if (req.user.role !== 'owner') return res.redirect('/denied');
  next();
}

module.exports = { attachUser, requireLogin, requirePST, requireOwner };
