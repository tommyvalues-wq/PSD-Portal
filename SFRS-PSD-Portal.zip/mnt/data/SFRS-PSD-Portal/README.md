# SFRS PSD Portal

## Run locally

```powershell
npm.cmd install
npm.cmd start
```

Open http://localhost:3000

## Important

This is an unofficial Roblox roleplay/community staff portal. Do not represent it as the real Staffordshire Fire and Rescue Service.

The `.env` file is included for your local use. Do not upload real secrets to a public GitHub repo.
